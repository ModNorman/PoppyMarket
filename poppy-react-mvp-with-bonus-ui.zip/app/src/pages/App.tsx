import React from 'react'
export default function App(){ return <div className="p-6">Poppy Market</div> }
